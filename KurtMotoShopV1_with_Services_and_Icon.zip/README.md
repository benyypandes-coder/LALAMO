
# Kurt MotoShop V1

Offline-first Android inventory app for Kurt Dylan Moto Shop.

## V1 Features
- Products inventory
- Services catalog
- Add / edit / delete products
- Add / edit / delete services
- Product name, price, stock and image
- Service name, price and description
- Search products and services
- Offline local persistence
- Racing-style dark UI
- Custom Kurt Dylan Moto Shop logo as the Android app icon
- GitHub Actions automatic APK build

## GitHub
The repository can be built automatically using `.github/workflows/build-apk.yml`.
Push to `main`/`master` or manually run the workflow from GitHub Actions.

## Planned future features
- Online cloud sync
- Stock-in / stock-out history
- Barcode scanner
- Categories
- Suppliers
- Sales and profit dashboard
- Admin PIN
