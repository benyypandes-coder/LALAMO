# Kurt MotoShop V1 - no custom ProGuard rules required.
