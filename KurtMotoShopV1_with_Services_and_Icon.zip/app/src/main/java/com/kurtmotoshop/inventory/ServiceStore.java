
package com.kurtmotoshop.inventory;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class ServiceStore {
    private static final String PREFS = "kurt_services";
    private static final String KEY = "services";

    public static List<ServiceItem> load(Context context) {
        List<ServiceItem> list = new ArrayList<>();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new ServiceItem(
                        o.optString("id"),
                        o.optString("name"),
                        o.optDouble("price", 0),
                        o.optString("description", "")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static void save(Context context, List<ServiceItem> services) {
        JSONArray arr = new JSONArray();
        try {
            for (ServiceItem s : services) {
                JSONObject o = new JSONObject();
                o.put("id", s.id);
                o.put("name", s.name);
                o.put("price", s.price);
                o.put("description", s.description == null ? "" : s.description);
                arr.put(o);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, arr.toString()).apply();
    }
}
