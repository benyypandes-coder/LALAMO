package com.kurtmotoshop.inventory;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class InventoryStore {
    private static final String PREFS = "kurt_inventory";
    private static final String KEY = "products";

    public static List<Product> load(Context context) {
        List<Product> list = new ArrayList<>();
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new Product(
                        o.optString("id"),
                        o.optString("name"),
                        o.optDouble("price", 0),
                        o.optInt("stock", 0),
                        o.optString("imagePath", "")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    public static void save(Context context, List<Product> products) {
        JSONArray arr = new JSONArray();
        try {
            for (Product p : products) {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                o.put("price", p.price);
                o.put("stock", p.stock);
                o.put("imagePath", p.imagePath == null ? "" : p.imagePath);
                arr.put(o);
            }
        } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, arr.toString()).apply();
    }
}
