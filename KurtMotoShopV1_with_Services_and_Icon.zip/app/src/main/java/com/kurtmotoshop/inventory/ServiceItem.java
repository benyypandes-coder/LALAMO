
package com.kurtmotoshop.inventory;

public class ServiceItem {
    public String id;
    public String name;
    public double price;
    public String description;

    public ServiceItem() {}

    public ServiceItem(String id, String name, double price, String description) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
    }
}
