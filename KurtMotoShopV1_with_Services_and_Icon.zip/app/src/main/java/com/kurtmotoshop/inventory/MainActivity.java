
package com.kurtmotoshop.inventory;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.graphics.drawable.GradientDrawable;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private final ArrayList<Product> products = new ArrayList<>();
    private final ArrayList<ServiceItem> services = new ArrayList<>();
    private LinearLayout listContainer, tabs;
    private EditText search;
    private TextView totalCount, totalStock;
    private boolean showingServices = false;
    private static final int PICK_IMAGE = 41;
    private String pendingImagePath = "";

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        products.addAll(InventoryStore.load(this));
        services.addAll(ServiceStore.load(this));
        buildUi();
        render();
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView tv(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false); b.setMinHeight(dp(44));
        b.setBackground(bg(Color.rgb(255,49,49), 12));
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(10));
        root.setBackgroundColor(Color.rgb(8,9,13));

        TextView title = tv("KURT MOTOSHOP", 24, Color.WHITE);
        title.setTypeface(null, 1);
        TextView sub = tv("INVENTORY  •  OFFLINE MODE", 11, Color.rgb(255,80,80));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(34)));
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(25)));

        tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button productsTab = button("PRODUCTS");
        Button servicesTab = button("SERVICES");
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(44), 1);
        tabs.addView(productsTab, tp);
        LinearLayout.LayoutParams ts = new LinearLayout.LayoutParams(0, dp(44), 1);
        ts.setMargins(dp(8),0,0,0);
        tabs.addView(servicesTab, ts);
        root.addView(tabs, new LinearLayout.LayoutParams(-1, dp(52)));
        productsTab.setOnClickListener(v -> { showingServices=false; render(); });
        servicesTab.setOnClickListener(v -> { showingServices=true; render(); });

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        totalCount = tv("", 14, Color.WHITE);
        totalStock = tv("", 14, Color.WHITE);
        stats.addView(card("ITEMS / SERVICES", totalCount), new LinearLayout.LayoutParams(0, dp(68), 1));
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(0, dp(68), 1);
        s.setMargins(dp(8),0,0,0);
        stats.addView(card("STOCK", totalStock), s);
        root.addView(stats);

        search = new EditText(this);
        search.setSingleLine(); search.setHint("Search...");
        search.setHintTextColor(Color.GRAY); search.setTextColor(Color.WHITE);
        search.setPadding(dp(14),0,dp(14),0);
        search.setBackground(bg(Color.rgb(24,26,33),12));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ renderList(); }
            public void afterTextChanged(Editable e){}
        });
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

        Button add = button("+  ADD " + (showingServices ? "SERVICE" : "PRODUCT"));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(48));
        ap.setMargins(0,dp(9),0,dp(9));
        root.addView(add, ap);
        add.setOnClickListener(v -> {
            if (showingServices) showServiceDialog(null);
            else showProductDialog(null);
        });

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private LinearLayout card(String label, TextView value) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(12),dp(6),dp(12),dp(6));
        c.setBackground(bg(Color.rgb(24,26,33),12));
        c.addView(tv(label,9,Color.GRAY),new LinearLayout.LayoutParams(-1,dp(20)));
        c.addView(value,new LinearLayout.LayoutParams(-1,dp(30)));
        return c;
    }

    private void render() {
        if (search != null) search.setHint(showingServices ? "Search services..." : "Search products...");
        renderList();
    }

    private void renderList() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();
        totalCount.setText(String.valueOf(showingServices ? services.size() : products.size()));

        if (showingServices) {
            totalStock.setText("N/A");
            int shown=0;
            for(ServiceItem s:services) {
                if(!s.name.toLowerCase().contains(q) && !s.description.toLowerCase().contains(q)) continue;
                listContainer.addView(serviceRow(s)); shown++;
            }
            if(shown==0) empty("No services yet. Tap + ADD SERVICE.");
        } else {
            int stock=0,shown=0;
            for(Product p:products) stock+=p.stock;
            totalStock.setText(String.valueOf(stock));
            for(Product p:products) {
                if(!p.name.toLowerCase().contains(q)) continue;
                listContainer.addView(productRow(p)); shown++;
            }
            if(shown==0) empty("No products yet. Tap + ADD PRODUCT.");
        }
    }

    private void empty(String text) {
        TextView e=tv(text,14,Color.GRAY); e.setGravity(Gravity.CENTER);
        e.setPadding(0,dp(35),0,dp(35)); listContainer.addView(e);
    }

    private LinearLayout productRow(Product p) {
        LinearLayout row = baseRow();
        ImageView img=new ImageView(this); img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(bg(Color.rgb(35,37,44),10));
        if(p.imagePath!=null&&!p.imagePath.isEmpty())
            img.setImageBitmap(BitmapFactory.decodeFile(p.imagePath));
        row.addView(img,new LinearLayout.LayoutParams(dp(74),dp(74)));

        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12),0,dp(5),0);
        TextView n=tv(p.name,15,Color.WHITE); n.setTypeface(null,1);
        info.addView(n,new LinearLayout.LayoutParams(-1,dp(28)));
        info.addView(tv(String.format(Locale.US,"₱%,.2f",p.price),13,Color.rgb(255,100,100)),new LinearLayout.LayoutParams(-1,dp(23)));
        info.addView(tv("Stock: "+p.stock,12,p.stock<=3?Color.rgb(255,170,60):Color.LTGRAY),new LinearLayout.LayoutParams(-1,dp(23)));
        row.addView(info,new LinearLayout.LayoutParams(0,-1,1));
        TextView menu=tv("⋮",28,Color.WHITE); menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v->showProductActions(p));
        row.addView(menu,new LinearLayout.LayoutParams(dp(40),dp(60)));
        return row;
    }

    private LinearLayout serviceRow(ServiceItem s) {
        LinearLayout row=baseRow();
        TextView icon=tv("⚙",30,Color.rgb(255,49,49)); icon.setGravity(Gravity.CENTER);
        icon.setBackground(bg(Color.rgb(35,37,44),12));
        row.addView(icon,new LinearLayout.LayoutParams(dp(74),dp(74)));
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12),0,dp(5),0);
        TextView n=tv(s.name,15,Color.WHITE); n.setTypeface(null,1);
        info.addView(n,new LinearLayout.LayoutParams(-1,dp(28)));
        info.addView(tv(String.format(Locale.US,"₱%,.2f",s.price),13,Color.rgb(255,100,100)),new LinearLayout.LayoutParams(-1,dp(23)));
        String d=s.description.isEmpty()?"Service":s.description;
        info.addView(tv(d,12,Color.LTGRAY),new LinearLayout.LayoutParams(-1,dp(23)));
        row.addView(info,new LinearLayout.LayoutParams(0,-1,1));
        TextView menu=tv("⋮",28,Color.WHITE); menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v->showServiceActions(s));
        row.addView(menu,new LinearLayout.LayoutParams(dp(40),dp(60)));
        return row;
    }

    private LinearLayout baseRow() {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),dp(8),dp(8),dp(8));
        row.setBackground(bg(Color.rgb(20,22,28),14));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(92));
        rp.setMargins(0,0,0,dp(8)); row.setLayoutParams(rp); return row;
    }

    private void showProductActions(Product p) {
        new AlertDialog.Builder(this).setTitle(p.name).setItems(new String[]{"Edit","Delete"},(d,w)->{
            if(w==0)showProductDialog(p); else new AlertDialog.Builder(this)
            .setTitle("Delete product?").setMessage("Remove \""+p.name+"\"?")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete",(x,y)->{
                products.remove(p); InventoryStore.save(this,products); renderList();
            }).show();
        }).show();
    }

    private void showServiceActions(ServiceItem s) {
        new AlertDialog.Builder(this).setTitle(s.name).setItems(new String[]{"Edit","Delete"},(d,w)->{
            if(w==0)showServiceDialog(s); else new AlertDialog.Builder(this)
            .setTitle("Delete service?").setMessage("Remove \""+s.name+"\"?")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete",(x,y)->{
                services.remove(s); ServiceStore.save(this,services); renderList();
            }).show();
        }).show();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.GRAY);
        e.setTextColor(Color.WHITE); e.setSingleLine(); e.setPadding(dp(12),0,dp(12),0);
        e.setBackground(bg(Color.rgb(24,26,33),10));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));
        p.setMargins(0,dp(5),0,dp(5)); e.setLayoutParams(p); return e;
    }

    private void showProductDialog(Product edit) {
        pendingImagePath=edit==null?"":(edit.imagePath==null?"":edit.imagePath);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20),4,dp(20),2);
        EditText name=field("Product name"),price=field("Price (₱)"),stock=field("Stock quantity");
        price.setInputType(2|8192); stock.setInputType(2);
        if(edit!=null){name.setText(edit.name);price.setText(String.valueOf(edit.price));stock.setText(String.valueOf(edit.stock));}
        box.addView(name);box.addView(price);box.addView(stock);
        Button image=button("📷  SELECT PRODUCT IMAGE"); box.addView(image,new LinearLayout.LayoutParams(-1,dp(46)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(edit==null?"Add Product":"Edit Product")
                .setView(box).setNegativeButton("Cancel",null).setPositiveButton(edit==null?"Add":"Save",null).create();
        image.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IMAGE);});
        dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{
            try{
                String n=name.getText().toString().trim(); if(n.isEmpty()){name.setError("Required");return;}
                double pr=Double.parseDouble(price.getText().toString()); int st=Integer.parseInt(stock.getText().toString());
                if(edit==null)products.add(new Product(UUID.randomUUID().toString(),n,pr,st,pendingImagePath));
                else{edit.name=n;edit.price=pr;edit.stock=st;edit.imagePath=pendingImagePath;}
                InventoryStore.save(this,products);renderList();dialog.dismiss();
            }catch(Exception e){Toast.makeText(this,"Enter valid price and stock.",Toast.LENGTH_SHORT).show();}
        })); dialog.show();
    }

    private void showServiceDialog(ServiceItem edit) {
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),4,dp(20),2);
        EditText name=field("Service name"),price=field("Price (₱)"),desc=field("Description (optional)");
        price.setInputType(2|8192);
        if(edit!=null){name.setText(edit.name);price.setText(String.valueOf(edit.price));desc.setText(edit.description);}
        box.addView(name);box.addView(price);box.addView(desc);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(edit==null?"Add Service":"Edit Service")
                .setView(box).setNegativeButton("Cancel",null).setPositiveButton(edit==null?"Add":"Save",null).create();
        dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{
            try{
                String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Required");return;}
                double pr=Double.parseDouble(price.getText().toString());
                String de=desc.getText().toString().trim();
                if(edit==null)services.add(new ServiceItem(UUID.randomUUID().toString(),n,pr,de));
                else{edit.name=n;edit.price=pr;edit.description=de;}
                ServiceStore.save(this,services);renderList();dialog.dismiss();
            }catch(Exception e){Toast.makeText(this,"Enter a valid service price.",Toast.LENGTH_SHORT).show();}
        }));dialog.show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_IMAGE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            try{
                InputStream in=getContentResolver().openInputStream(data.getData());
                File out=new File(getFilesDir(),"img_"+System.currentTimeMillis()+".jpg");
                FileOutputStream fos=new FileOutputStream(out);byte[] b=new byte[8192];int n;
                while((n=in.read(b))>0)fos.write(b,0,n);fos.close();in.close();
                pendingImagePath=out.getAbsolutePath();
                Toast.makeText(this,"Image selected.",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Could not load image.",Toast.LENGTH_SHORT).show();}
        }
    }
}
