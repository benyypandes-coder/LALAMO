package com.kurtmotoshop.inventory;

public class Product {
    public String id;
    public String name;
    public double price;
    public int stock;
    public String imagePath;

    public Product() {}

    public Product(String id, String name, double price, int stock, String imagePath) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.imagePath = imagePath;
    }
}
