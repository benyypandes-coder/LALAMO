using System.Globalization;
using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory;

public partial class ServiceEditorPage : ContentPage
{
    private readonly InventoryStore _store;
    private readonly ShopService _service;

    public ServiceEditorPage(ShopService? service = null)
    {
        InitializeComponent();
        _store = IPlatformApplication.Current?.Services.GetService<InventoryStore>() ?? new InventoryStore();
        _service = service ?? new ShopService();
        if (service is not null)
        {
            HeaderLabel.Text = "EDIT SERVICE"; DeleteButton.IsVisible = true;
            NameEntry.Text = service.Name; PriceEntry.Text = service.LaborPrice.ToString(CultureInfo.InvariantCulture);
        }
    }

    private async void Save_Clicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameEntry.Text)) { await DisplayAlert("Missing name", "Please enter the labor/service name.", "OK"); return; }
        if (!decimal.TryParse(PriceEntry.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out var price)) { await DisplayAlert("Invalid price", "Enter a valid labor price.", "OK"); return; }
        _service.Name = NameEntry.Text.Trim(); _service.LaborPrice = price;
        await _store.AddOrUpdateServiceAsync(_service); await Navigation.PopAsync();
    }

    private async void Delete_Clicked(object sender, EventArgs e)
    {
        if (await DisplayAlert("Delete service?", $"Remove {_service.Name}?", "Delete", "Cancel"))
        { await _store.DeleteServiceAsync(_service); await Navigation.PopAsync(); }
    }
}
