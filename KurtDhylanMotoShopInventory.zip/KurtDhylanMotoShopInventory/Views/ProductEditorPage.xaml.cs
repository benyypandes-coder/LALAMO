using System.Globalization;
using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory;

public partial class ProductEditorPage : ContentPage
{
    private readonly InventoryStore _store;
    private readonly Product _product;

    public ProductEditorPage(Product? product = null)
    {
        InitializeComponent();
        _store = IPlatformApplication.Current?.Services.GetService<InventoryStore>() ?? new InventoryStore();
        _product = product ?? new Product();
        if (product is not null)
        {
            HeaderLabel.Text = "EDIT PRODUCT"; DeleteButton.IsVisible = true;
            BrandEntry.Text = product.Brand; ModelEntry.Text = product.Model; NameEntry.Text = product.Name;
            PriceEntry.Text = product.Price.ToString(CultureInfo.InvariantCulture); StockEntry.Text = product.Stock.ToString();
        }
    }

    private async void Save_Clicked(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(NameEntry.Text)) { await DisplayAlert("Missing name", "Please enter the product name.", "OK"); return; }
        if (!decimal.TryParse(PriceEntry.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out var price)) { await DisplayAlert("Invalid price", "Enter a valid price.", "OK"); return; }
        if (!int.TryParse(StockEntry.Text, out var stock) || stock < 0) { await DisplayAlert("Invalid stock", "Enter a valid stock quantity.", "OK"); return; }
        _product.Brand = BrandEntry.Text?.Trim() ?? ""; _product.Model = ModelEntry.Text?.Trim() ?? ""; _product.Name = NameEntry.Text.Trim(); _product.Price = price; _product.Stock = stock;
        await _store.AddOrUpdateProductAsync(_product); await Navigation.PopAsync();
    }

    private async void Delete_Clicked(object sender, EventArgs e)
    {
        if (await DisplayAlert("Delete product?", $"Remove {_product.Name} from inventory?", "Delete", "Cancel"))
        { await _store.DeleteProductAsync(_product); await Navigation.PopAsync(); }
    }
}
