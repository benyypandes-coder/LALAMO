# Kurt Dhylan Moto Shop Inventory

Android .NET MAUI inventory app for Kurt Dhylan Moto Shop.

## Included
- Racing red/black app icon
- Dashboard: product count, service count, low-stock count
- Add/Edit/Delete Products
  - Brand
  - Model
  - Product Name
  - Price
  - Stocks
- Add/Edit/Delete Services
  - Labor/Service Name
  - Labor Price
- Product search
- Service search
- Quick + / - stock adjustment
- Offline-first local JSON storage
- GitHub Actions workflow that builds an APK and uploads it as an artifact

## Build locally
```bash
dotnet workload install maui-android
dotnet restore
dotnet build -c Release -f net9.0-android
```

## GitHub
Push this project to GitHub. The workflow in `.github/workflows/build-android.yml` runs on pushes to `main`/`master` and can also be started manually from Actions. Download the APK from the workflow's Artifacts section.
