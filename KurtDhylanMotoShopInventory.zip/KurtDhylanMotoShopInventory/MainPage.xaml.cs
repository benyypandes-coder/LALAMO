using System.Collections.ObjectModel;
using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory;

public partial class MainPage : ContentPage
{
    private readonly InventoryStore _store;
    private readonly ObservableCollection<Product> _products = new();
    private readonly ObservableCollection<ShopService> _services = new();

    public MainPage()
    {
        InitializeComponent();
        _store = IPlatformApplication.Current?.Services.GetService<InventoryStore>() ?? new InventoryStore();
        ProductsView.ItemsSource = _products;
        ServicesView.ItemsSource = _services;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _store.LoadAsync();
        RefreshLists();
    }

    private void RefreshLists()
    {
        var productQuery = SearchBox?.Text?.Trim() ?? "";
        var serviceQuery = ServiceSearchBox?.Text?.Trim() ?? "";

        _products.Clear();
        foreach (var p in _store.Data.Products.Where(p => string.IsNullOrWhiteSpace(productQuery) || p.SearchText.Contains(productQuery, StringComparison.OrdinalIgnoreCase)).OrderBy(p => p.Name))
            _products.Add(p);

        _services.Clear();
        foreach (var s in _store.Data.Services.Where(s => string.IsNullOrWhiteSpace(serviceQuery) || s.Name.Contains(serviceQuery, StringComparison.OrdinalIgnoreCase)).OrderBy(s => s.Name))
            _services.Add(s);

        ProductCountLabel.Text = _store.Data.Products.Count.ToString();
        ServiceCountLabel.Text = _store.Data.Services.Count.ToString();
        LowStockLabel.Text = _store.Data.Products.Count(p => p.Stock <= 3).ToString();
    }

    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => RefreshLists();
    private void ServiceSearchBox_TextChanged(object sender, TextChangedEventArgs e) => RefreshLists();

    private async void AddProduct_Clicked(object sender, EventArgs e) => await Navigation.PushAsync(new ProductEditorPage());
    private async void AddService_Clicked(object sender, EventArgs e) => await Navigation.PushAsync(new ServiceEditorPage());

    private async void EditProduct_Clicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.BindingContext is Product p)
            await Navigation.PushAsync(new ProductEditorPage(p));
    }

    private async void EditService_Clicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.BindingContext is ShopService s)
            await Navigation.PushAsync(new ServiceEditorPage(s));
    }

    private async void PlusStock_Clicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.BindingContext is Product p) { p.Stock++; await _store.SaveAsync(); RefreshLists(); }
    }

    private async void MinusStock_Clicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.BindingContext is Product p && p.Stock > 0) { p.Stock--; await _store.SaveAsync(); RefreshLists(); }
    }
}
