namespace KurtDhylanMotoShopInventory;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new NavigationPage(new MainPage())
        {
            BarBackgroundColor = Color.FromArgb("#090909"),
            BarTextColor = Colors.White
        };
    }
}
