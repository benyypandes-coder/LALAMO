using System.Text.Json;
using KurtDhylanMotoShopInventory.Models;

namespace KurtDhylanMotoShopInventory.Services;

public class InventoryStore
{
    private readonly string _file = Path.Combine(FileSystem.AppDataDirectory, "inventory.json");
    private readonly JsonSerializerOptions _options = new() { WriteIndented = true };
    public InventoryData Data { get; private set; } = new();

    public async Task LoadAsync()
    {
        try
        {
            if (File.Exists(_file))
            {
                var json = await File.ReadAllTextAsync(_file);
                Data = JsonSerializer.Deserialize<InventoryData>(json, _options) ?? new InventoryData();
            }
        }
        catch
        {
            Data = new InventoryData();
        }
    }

    public async Task SaveAsync()
    {
        var json = JsonSerializer.Serialize(Data, _options);
        await File.WriteAllTextAsync(_file, json);
    }

    public async Task AddOrUpdateProductAsync(Product item)
    {
        var old = Data.Products.FirstOrDefault(x => x.Id == item.Id);
        if (old is null) Data.Products.Add(item);
        else
        {
            old.Brand = item.Brand; old.Model = item.Model; old.Name = item.Name;
            old.Price = item.Price; old.Stock = item.Stock;
        }
        await SaveAsync();
    }

    public async Task DeleteProductAsync(Product item)
    {
        Data.Products.RemoveAll(x => x.Id == item.Id);
        await SaveAsync();
    }

    public async Task AddOrUpdateServiceAsync(ShopService item)
    {
        var old = Data.Services.FirstOrDefault(x => x.Id == item.Id);
        if (old is null) Data.Services.Add(item);
        else { old.Name = item.Name; old.LaborPrice = item.LaborPrice; }
        await SaveAsync();
    }

    public async Task DeleteServiceAsync(ShopService item)
    {
        Data.Services.RemoveAll(x => x.Id == item.Id);
        await SaveAsync();
    }
}
