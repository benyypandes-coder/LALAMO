namespace KurtDhylanMotoShopInventory.Models;

public class InventoryData
{
    public List<Product> Products { get; set; } = new();
    public List<ShopService> Services { get; set; } = new();
}
