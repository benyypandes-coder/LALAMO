namespace KurtDhylanMotoShopInventory.Models;

public class ShopService
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public decimal LaborPrice { get; set; }
}
