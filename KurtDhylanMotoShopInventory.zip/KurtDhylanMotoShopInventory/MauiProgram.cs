using Microsoft.Extensions.Logging;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

        builder.Services.AddSingleton<InventoryStore>();
        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddTransient<ProductEditorPage>();
        builder.Services.AddTransient<ServiceEditorPage>();

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }
}
